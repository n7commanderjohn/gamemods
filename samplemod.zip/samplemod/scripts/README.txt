------------------------------------------
This is where you can completely override scripts from the game. You must use the same directory structure as the game, and it will automagically override them.

Note that while this is the most powerful way to write a mod, it is also the least bulletproof in terms of updates. The main game updates WILL break these mods!