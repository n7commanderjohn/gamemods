name = "Allow Map Usage With Werewoodie and Iron Lord Forms"
version = "1.01"
description = [[Allow map usage with WereWoodie and Iron Lord Forms.
You will have to use the Open Map action bind though, as I can't figure out how to get the map button to show.
Only tested with Hamlet compatibility.

Version: ]]..version

author = "N7 Commander John"
forumthread = "files/file/1997-allow-map-usage-with-werebeaver-and-iron-lord-forms/"
icon = "modicon.tex"
icon_atlas = "modicon.xml"

api_version = 6

-- dont_starve_compatible = true
-- reign_of_giants_compatible = true
-- shipwrecked_compatible = true
hamlet_compatible = true
dst_compatible = false
