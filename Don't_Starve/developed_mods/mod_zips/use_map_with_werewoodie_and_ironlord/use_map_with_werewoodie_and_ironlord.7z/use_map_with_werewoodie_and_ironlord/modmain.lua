-- local GetPlayer = GLOBAL.GetPlayer
-- local GetWorld = GLOBAL.GetWorld
-- local Class = GLOBAL.Class
local require = GLOBAL.require

local PauseScreen = require "screens/pausescreen"
local PlayerHud = require "screens/playerhud"
-- local Badge = require "widgets/badge"

-- local BeaverBadge = Class(Badge, function(self, owner)
--     Badge._ctor(self, "beaver_meter", owner)
-- end)

function PlayerHud:OnControl(control, down)
    if PlayerHud._base.OnControl(self, control, down) then return true end
    if not self.shown then return end

    if not down and control == GLOBAL.CONTROL_PAUSE then
        TheFrontEnd:PushScreen(PauseScreen())
        return true
    end

    local blockHUDInput = (self.owner:HasTag("beaver") or self.owner:HasTag("ironlord"))

    if not down and control == GLOBAL.CONTROL_MAP then
        -- if not blockHUDInput then
            self.controls:ToggleMap()			
            return true
        -- end
    end
    
    if not down and control == GLOBAL.CONTROL_CANCEL then
        if self:IsControllerCraftingOpen() then
            if self.controls.crafttabs:GetControllerLevel() == 0 then
                self:CloseControllerCrafting()
            end
        end

        if self:IsControllerInventoryOpen() then
            self:CloseControllerInventory()
        end
    end

    
    if down and control == GLOBAL.CONTROL_OPEN_CRAFTING then
        if self:IsControllerCraftingOpen() then
            self:CloseControllerCrafting()
        elseif not blockHUDInput then
            self:OpenControllerCrafting()
        end
    end

    if down and control == GLOBAL.CONTROL_OPEN_INVENTORY then
        if self:IsControllerInventoryOpen() then
            self:CloseControllerInventory()
        elseif not blockHUDInput then
            self:OpenControllerInventory()
        end
    end
    
    if not blockHUDInput then
        --inventory hotkeys
        if down and control >= GLOBAL.CONTROL_INV_1 and control <= GLOBAL.CONTROL_INV_10 then
            local num = (control - GLOBAL.CONTROL_INV_1) + 1
            local item = self.owner.components.inventory:GetItemInSlot(num)
            self.owner.components.inventory:UseItemFromInvTile(item)
            return true
        end
    end
end

-- local function SetHUDState(inst)
--     if inst.HUD then
--         if inst.components.beaverness:IsBeaver() and not inst.HUD.controls.beaverbadge then
--             inst.HUD.controls.beaverbadge = GetPlayer().HUD.controls.sidepanel:AddChild(BeaverBadge(inst))
--             inst.HUD.controls.beaverbadge:SetPosition(0,-100,0)
--             inst.HUD.controls.beaverbadge:SetPercent(1)
            
--             inst.HUD.controls.beaverbadge.inst:ListenForEvent("beavernessdelta", function(_, data) 
--                 inst.HUD.controls.beaverbadge:SetPercent(inst.components.beaverness:GetPercent(), inst.components.beaverness.max)
--                 if not data.overtime then
--                     if data.newpercent > data.oldpercent then
--                         inst.HUD.controls.beaverbadge:PulseGreen()
--                         TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/health_up")
--                     elseif data.newpercent < data.oldpercent then
--                         TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/health_down")
--                         inst.HUD.controls.beaverbadge:PulseRed()
--                     end
--                 end
--             end, inst)
--             inst.HUD.controls.crafttabs:Hide()
--             inst.HUD.controls.inv:Hide()
--             inst.HUD.controls.status:Hide()
--             -- inst.HUD.controls.mapcontrols.minimapBtn:Show()

--             inst.HUD.beaverOL = inst.HUD.under_root:AddChild(Image("images/woodie.xml", "beaver_vision_OL.tex"))
--             inst.HUD.beaverOL:SetVRegPoint(ANCHOR_MIDDLE)
--             inst.HUD.beaverOL:SetHRegPoint(ANCHOR_MIDDLE)
--             inst.HUD.beaverOL:SetVAnchor(ANCHOR_MIDDLE)
--             inst.HUD.beaverOL:SetHAnchor(ANCHOR_MIDDLE)
--             inst.HUD.beaverOL:SetScaleMode(SCALEMODE_FILLSCREEN)
--             inst.HUD.beaverOL:SetClickable(false)
        
--         elseif not inst.components.beaverness:IsBeaver() and inst.HUD.controls.beaverbadge then
--             if inst.HUD.controls.beaverbadge then
--                 inst.HUD.controls.beaverbadge:Kill()
--                 inst.HUD.controls.beaverbadge = nil
--             end

--             if inst.HUD.beaverOL then
--                 inst.HUD.beaverOL:Kill()
--                 inst.HUD.beaverOL = nil
--             end

--             inst.HUD.controls.crafttabs:Show()
--             inst.HUD.controls.inv:Show()
--             inst.HUD.controls.status:Show()
--             inst.HUD.controls.mapcontrols.minimapBtn:Show()
--         end
--     end
-- end

-- local function BecomeWoodie(inst)
    
--     inst.components.poisonable:SetBlockAll(nil)

--     inst.beaver = false
--     inst.ActionStringOverride = nil
--     inst.AnimState:SetBank("wilson")
--     inst.AnimState:SetBuild("woodie")
--     inst:SetStateGraph("SGwilson")
--     inst:RemoveTag("beaver")
    
--     inst:RemoveComponent("worker")
--     inst.components.talker:StopIgnoringAll()
--     inst.components.locomotor.runspeed = TUNING.WILSON_RUN_SPEED
--     inst.components.combat:SetDefaultDamage(TUNING.UNARMED_DAMAGE)
    
--     inst.components.playercontroller.actionbuttonoverride = nil
--     inst.components.playeractionpicker.leftclickoverride = nil
--     inst.components.playeractionpicker.rightclickoverride = nil
--     inst.components.eater:SetOmnivore()


--     inst.components.hunger:Resume()
--     inst.components.sanity.ignore = false
--     inst.components.health.redirect = nil

--     inst.components.beaverness:StartTimeEffect(2, -1)

--     inst:RemoveEventCallback("oneatsomething", onbeavereat)
--     inst.Light:Enable(false)
--     inst.components.dynamicmusic:Enable()
--     inst.SoundEmitter:KillSound("beavermusic")
--     GetWorld().components.colourcubemanager:SetOverrideColourCube(nil)
--     inst.components.temperature:SetTemp(nil)
--     inst:DoTaskInTime(0, function() SetHUDState(inst) end)
    
-- end

-- local function BecomeBeaver(inst)

--     inst.components.poisonable:SetBlockAll(true)

--     inst.beaver = true
--     inst.ActionStringOverride = beaveractionstring
--     inst:AddTag("beaver")
--     inst.AnimState:SetBuild("werebeaver_build")
--     inst.AnimState:SetBank("werebeaver")
--     inst:SetStateGraph("SGwerebeaver")
--     inst.components.talker:IgnoreAll()
--     inst.components.combat:SetDefaultDamage(TUNING.BEAVER_DAMAGE)

--     inst.components.locomotor.runspeed = TUNING.WILSON_RUN_SPEED*1.1
--     inst.components.inventory:DropEverything()
    
--     inst.components.playercontroller.actionbuttonoverride = BeaverActionButton
--     inst.components.playeractionpicker.leftclickoverride = LeftClickPicker
--     inst.components.playeractionpicker.rightclickoverride = RightClickPicker
--     inst.components.eater:SetBeaver()

--     inst:AddComponent("worker")
--     inst.components.worker:SetAction(ACTIONS.DIG, 1)
--     inst.components.worker:SetAction(ACTIONS.CHOP, 4)
--     inst.components.worker:SetAction(ACTIONS.MINE, 1)
--     inst.components.worker:SetAction(ACTIONS.HAMMER, 1)
--     inst.components.worker:SetAction(ACTIONS.HACK, 1)	
--     inst:ListenForEvent("oneatsomething", onbeavereat)

--     inst.components.sanity:SetPercent(1)
--     inst.components.health:SetPercent(1)
--     inst.components.hunger:SetPercent(1)

--     inst.components.hunger:Pause()
--     inst.components.sanity.ignore = true
--     inst.components.health.redirect = beaverhurt
--     inst.components.health.redirect_percent = .25

--     local dt = 3
--     local BEAVER_DRAIN_TIME = 120
--     inst.components.beaverness:StartTimeEffect(dt, (-100/BEAVER_DRAIN_TIME)*dt)
--     inst.Light:Enable(true)
--     inst.components.dynamicmusic:Disable()
--     inst.SoundEmitter:PlaySound("dontstarve/music/music_hoedown", "beavermusic")
--     GetWorld().components.colourcubemanager:SetOverrideColourCube("images/colour_cubes/beaver_vision_cc.tex")
--     inst.components.temperature:SetTemp(20)
--     inst:DoTaskInTime(0, function() SetHUDState(inst) end)
    
--     if inst:HasTag("lightsource") then       
--         inst:RemoveTag("lightsource")    
--     end
-- end

-- local function OverrideBeaverMapStuff(inst)
--     inst.components.beaverness.makeperson = BecomeWoodie
--     inst.components.beaverness.makebeaver = BecomeBeaver
-- end


-- AddComponentPostInit("woodie", OverrideBeaverMapStuff)
