name = "Code Tips And Tricks"
description = "Examples of some useful coding tricks."
author = "squeek"
version = "1.0"
forumthread = ""
api_version = 4